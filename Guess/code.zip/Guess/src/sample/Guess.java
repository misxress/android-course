package sample;

import com.sun.org.apache.xpath.internal.operations.Bool;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Guess {

    private final List<Integer> keys = new ArrayList<Integer>(4);
    private final List<Boolean> isExist = new ArrayList<Boolean>(10);
    private final Random random = new Random();


    public Guess() {
        initData();

        initKeys();
//        printKeys();
//        List<Integer> test = new ArrayList<Integer>();
//        test.add(1);
//        test.add(1);
//        test.add(1);
//        test.add(1);
//        System.out.println(tryOne(test));
    }

    public void initKeys() {
        for(int i = 0; i < 10; i++) {
            isExist.set(i,false);
        }
        for(int i = 0; i < 4; i++){
            Integer temp = random.nextInt(10);
            while(isExist.get(temp)) {
                temp = random.nextInt(10);
            }
            keys.set(i, temp);
            isExist.set(temp,true);
        }
    }

    /**
     * 进行一次猜测
     * @param list
     * @return
     */
    public List<Integer> tryOne(List<Integer> list) {

        List<Integer> ans = new ArrayList<Integer>();
        int count1 = 0,count2 = 0;
        //猜测长度是否符合要求
        if(list.size() != 4) {
            throw new RuntimeException("猜测的数据列表长度错误");
        }
        //猜测相等的个数
        for(int i = 0; i < 4; i++) {
            int count2_ok = 0;
            for(int j = 0; j < 4; j++) {
                if (list.get(i).intValue() == keys.get(j).intValue()) {
                    if (i == j) {//位置相等
                        count1++;
                    } else {//位置不相等
                        count2_ok = 1;
                    }
                }
            }
            if(count2_ok == 1) {
                count2++;
            }
        }

        //添加计算结果
        ans.add(count1);
        ans.add(count2);
        return ans;
    }

    public void printKeys() {
        System.out.print("Keys: ");
        for(Integer key : keys){
            System.out.print(key+" ");
        }
        System.out.println();
    }

    private void initData() {
        for(int i = 0; i < 4; i++) {
            keys.add(0);
        }
        for(int i = 0; i < 10; i++) {
            isExist.add(false);
        }
    }
}
