package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;


import java.util.*;

public class Controller {

    @FXML
    private BorderPane borderPane;

    @FXML
    private ChoiceBox<Integer> choiceBox1;

    @FXML
    private ChoiceBox<Integer> choiceBox2;

    @FXML
    private ChoiceBox<Integer> choiceBox3;

    @FXML
    private ChoiceBox<Integer> choiceBox4;

    private final Guess guess = new Guess();

    private final Rank rank = new Rank();

    private final List<ChoiceBox<Integer>> choiceBoxes = new ArrayList<ChoiceBox<Integer>>();

    private Map<String,Integer> users;

    private String myUser;

    private Integer myScore;

    @FXML
    private TextArea textArea;

    @FXML
    private Label label;

    /**
     * 猜测一次
     */
    @FXML
    public void tryOne() {
        List<Integer> inlist = new ArrayList<Integer>();
        for(int i = 0; i < 4; i++){
            inlist.add(choiceBoxes.get(i).getValue());
        }
        List<Integer> ans = guess.tryOne(inlist);
        if(ans.get(0) != 4) {
            textArea.setText("猜到的个数：" + ans.get(0) + "\n猜到但位置不对的个数：" + ans.get(1));
        }else {
            guess.initKeys();
            myScore++;
            label.setText("user: "+myUser+"\tscore: "+myScore);
            users.replace(myUser,myScore);
            textArea.setText("恭喜猜测成功,已开始新的游戏");
        }
    }

    /**
     * 新游戏
     */
    @FXML
    public void newGame() {
        guess.initKeys();
        textArea.setText("新游戏已经开始");
    }

    /**
     * 打开排行榜
     */
    @FXML
    public void openRank() {
        String temp = "";

        for(String str: users.keySet()) {
            temp += (str+": "+users.get(str))+"\n";
        }

        textArea.setText(temp);
    }

    /**
     * 游戏玩法
     */
    @FXML
    public void how() {
        textArea.setText("1.选择数字后,点击Guess进行猜题,本框显示结果\n"+
                "2.所给四个数字无重复,但是选择可以有重复\n"+
                "3.相同的猜中但是位置不正确的数字可重复计数\n"+
                "4.猜对一次,该账号记一分\n"+
                "5.排行榜记录为rank.json文件\n");
    }

    /**
     * 关于
     */
    @FXML
    public void about() {
        textArea.setText("使用了Gson  commons-io  lombok等包\n"+
                "----  2020-4-8");
    }

    /**
     * 关闭游戏
     */
    public void closeGame() {
        rank.save(users);
    }

    /**
     * 初始化动态组件
     */
    public void Init() {
        /**
         * 设置选项0-9
         */
        ObservableList<Integer> alist = FXCollections.observableArrayList(0,1,2,3,4,5,6,7,8,9);

        choiceBoxes.add(choiceBox1);
        choiceBoxes.add(choiceBox2);
        choiceBoxes.add(choiceBox3);
        choiceBoxes.add(choiceBox4);

        for(int i = 0; i < 4; i++){
            choiceBoxes.get(i).setItems(alist);
            choiceBoxes.get(i).setValue(0);
        }

        /**
         * 获取用户列表和用户名
         */
        users = rank.load();
        TextInputDialog dialog = new TextInputDialog("默认值");
        dialog.setTitle("登入");
        dialog.setContentText("用户名：");
        dialog.setHeaderText("请首先输入您的用户名以记录成绩");
        dialog.getEditor().setText("");

        Optional result = dialog.showAndWait();

        result.ifPresent(value -> {
            textArea.setText(value+",欢迎来到猜数字游戏!");
            myUser = value.toString();
            if(users == null) {
                myScore = 0;
                users = new HashMap<String, Integer>();
                users.put(myUser,0);
            } else if(users.containsKey(myUser)) {
                myScore = users.get(myUser);
            }else if(value.toString().equals("")){
                throw new RuntimeException("输入名不对");
            }else{
                myScore = 0;
                users.put(myUser,0);
            }
            label.setText("user: "+myUser+"\tscore: "+myScore);
        });
    }
}
