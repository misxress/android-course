package sample;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.io.FileUtils;

import java.io.*;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class Rank {

    private final File file = new File("./rank.json");

    private final Gson gson = new Gson();

    public Rank() {
        if (!file.exists()) {
            try {
                file.createNewFile();
            }catch(IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Map<String,Integer> load() {
        try {
            String jsonString = FileUtils.readFileToString(file, "UTF-8");
            Type type = new TypeToken<Map<String, Integer>>() {
            }.getType();
            Map<String, Integer> ans = gson.fromJson(jsonString, type);
            return ans;
        }catch (IOException e){
            e.printStackTrace();
        }
        return null;
    }

    public void save(Map<String,Integer> inRank) {
        try {
            Map<String, String> map = new HashMap<String, String>();

            String jsonString = gson.toJson(inRank);

            FileUtils.writeStringToFile(file, jsonString, "UTF-8");
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
