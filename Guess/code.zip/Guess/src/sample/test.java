package sample;

import java.io.InputStream;
import java.util.*;

public class test {
    public static void main(String[] args) {
        Rank rank = new Rank();
        Map<String,Integer> map = new HashMap<>();
//        map.put("misxress",23);
//        map.put("rmistake",22);
//        rank.save(map);
        map = rank.load();
        System.out.println(map.get("misxress"));
    }
}
